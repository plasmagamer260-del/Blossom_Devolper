import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Code2, Rocket, Smartphone, Zap } from 'lucide-react';
import { motion } from 'motion/react';

export default function Home() {
  return (
    <div className="space-y-32 pb-32">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-20 pb-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900 border border-white/10 text-slate-400 text-sm font-medium mb-8"
          >
            <span className="flex h-2 w-2 rounded-full bg-sky-400 animate-pulse" />
            Expert engineering meets modern design
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-6xl md:text-[64px] font-display font-black tracking-tight mb-4 leading-[1]"
          >
            Blossom <span className="text-gradient">Developers</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-lg text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            We Build Professional Websites That Grow Your Business. 
            Expert engineering meets modern design aesthetics.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link
              to="/contact"
              className="btn-primary"
            >
              Get Started
            </Link>
            <Link
              to="/services"
              className="btn-secondary"
            >
              Our Services
            </Link>
          </motion.div>
        </div>

        {/* Background Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-sky-500/5 rounded-full blur-[120px] -z-10" />
      </section>

      {/* Services Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Our Expertise</h2>
          <p className="text-slate-400">Everything you need to succeed online.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            {
              title: 'Business Website',
              desc: 'Professional brand presence tailored for your corporate identity.',
              icon: Rocket
            },
            {
              title: 'Ecommerce Website',
              desc: 'Robust online stores with seamless payment management.',
              icon: Zap
            },
            {
              title: 'Landing Page',
              desc: 'High-converting landing pages designed to turn visitors into customers.',
              icon: Smartphone
            }
          ].map((service, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -5 }}
              className="p-8 bg-slate-900/40 border border-white/10 rounded-xl hover:border-sky-400 transition-colors group"
            >
              <h3 className="text-lg font-bold mb-2 text-sky-400">{service.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-6">{service.desc}</p>
              <Link to="/services" className="text-sky-400 text-sm font-semibold flex items-center gap-2 hover:gap-3 transition-all">
                Learn More <ArrowRight className="w-4 h-4" />
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="bg-slate-900/30 py-32 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-display font-bold mb-8">Why Choose Blossom Developers?</h2>
              <div className="space-y-6">
                {[
                  { title: 'Modern Design', desc: 'We use the latest design trends to keep your site fresh.' },
                  { title: 'Fast Performance', desc: 'Optimized code for lightning-fast loading speeds.' },
                  { title: 'Responsive Layout', desc: 'Your website will look perfect on all devices.' },
                  { title: 'SEO Optimized', desc: 'Built with search engines in mind to help you rank.' }
                ].map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="mt-1">
                      <CheckCircle2 className="w-6 h-6 text-sky-400" />
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">{item.title}</h4>
                      <p className="text-slate-400 text-sm">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square bg-slate-900/50 rounded-2xl border border-white/10 flex items-center justify-center overflow-hidden">
                <Code2 className="w-48 h-48 text-slate-800" />
                <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:40px_40px]" />
              </div>
              {/* Floating Badge */}
              <div className="absolute -bottom-6 -right-6 p-6 bg-glass rounded-xl shadow-2xl">
                <div className="text-3xl font-bold text-sky-400">100%</div>
                <div className="text-sm text-slate-400">Client Satisfaction</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900/50 border border-white/10 rounded-3xl p-12 md:p-20 text-center relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-6">Ready to grow your business?</h2>
            <p className="text-slate-400 text-lg mb-10 max-w-2xl mx-auto">
              Contact us today for a free consultation and let's build something amazing together.
            </p>
            <Link
              to="/contact"
              className="btn-primary"
            >
              Start Your Project
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
