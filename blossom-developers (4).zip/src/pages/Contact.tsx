import React from 'react';
import { Phone, Mail, MapPin, Send, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';

export default function Contact() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission logic here
    alert('Thank you for your message! We will get back to you soon.');
  };

  return (
    <div className="pb-32">
      {/* Header */}
      <section className="pt-20 pb-24 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-display font-bold mb-6"
          >
            Get in <span className="text-gradient">Touch</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-zinc-400 max-w-2xl mx-auto text-lg"
          >
            Have a question or want to start a project? We'd love to hear from you.
          </motion.p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h2 className="text-3xl font-display font-bold mb-8">Get in Touch</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="form-group">
                <input
                  type="text"
                  required
                  placeholder="Full Name"
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:border-sky-500 transition-colors text-white"
                />
              </div>
              <div className="form-group">
                <input
                  type="email"
                  required
                  placeholder="Email Address"
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:border-sky-500 transition-colors text-white"
                />
              </div>
              <div className="form-group">
                <textarea
                  required
                  rows={4}
                  placeholder="Project Description"
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:border-sky-500 transition-colors text-white resize-none"
                />
              </div>
              <button
                type="submit"
                className="btn-primary w-full"
              >
                Send Message
              </button>
            </form>
          </motion.div>

          {/* Contact Info Box */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-sky-500 text-slate-950 p-10 rounded-xl"
          >
            <h3 className="text-2xl font-bold mb-6">Direct Contact</h3>
            <div className="space-y-6">
              <div>
                <p className="font-bold text-lg">Naveed Butt</p>
                <p className="text-slate-900/70">Founder & Lead Developer</p>
              </div>
              <div className="space-y-1">
                <p className="flex items-center gap-2">📞 03204703662</p>
                <p className="flex items-center gap-2 break-all">📧 blossomwebsitedevolper@gmail.com</p>
              </div>
              <div className="flex flex-col gap-3 pt-4">
                <a
                  href="https://wa.me/03204703662"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-[#25D366] text-white font-bold rounded-lg hover:opacity-90 transition-all"
                >
                  <MessageCircle className="w-5 h-5" /> WhatsApp Us
                </a>
                <a
                  href="tel:03204703662"
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-white text-slate-950 font-bold rounded-lg hover:opacity-90 transition-all"
                >
                  <Phone className="w-5 h-5" /> Direct Call
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
