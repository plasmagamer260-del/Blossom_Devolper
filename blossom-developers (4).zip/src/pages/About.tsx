import { Link } from 'react-router-dom';
import { Award, Users, Target, Heart, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

export default function About() {
  return (
    <div className="pb-32">
      {/* Hero Section */}
      <section className="pt-20 pb-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h1 className="text-4xl md:text-6xl font-display font-black tracking-tight mb-8 leading-tight">
                About <span className="text-gradient">Blossom Developers</span>
              </h1>
              <p className="text-slate-400 text-lg leading-relaxed mb-8">
                Naveed Butt is the driving force behind Blossom Developers. With years of experience in full-stack engineering, 
                he bridges the gap between complex functionality and clean design.
              </p>
              <div className="grid grid-cols-2 gap-8 mb-10">
                <div>
                  <div className="text-3xl font-bold text-sky-400 mb-1">50+</div>
                  <div className="text-sm text-slate-500 uppercase tracking-wider">Projects Done</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-sky-400 mb-1">100%</div>
                  <div className="text-sm text-slate-500 uppercase tracking-wider">Happy Clients</div>
                </div>
              </div>
              <Link
                to="/contact"
                className="btn-primary"
              >
                Start Your Project
              </Link>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative"
            >
              <div className="aspect-square bg-slate-900/50 rounded-2xl border border-white/10 overflow-hidden relative group">
                <img
                  src="https://picsum.photos/seed/team/800/800"
                  alt="Our Team"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover opacity-40 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
              </div>
              {/* Floating Card */}
              <div className="absolute -bottom-10 -left-10 p-8 bg-glass rounded-2xl shadow-2xl max-w-xs">
                <p className="text-slate-300 italic mb-4 text-sm">
                  "Our goal is to build websites that aren't just beautiful, but also functional and high-performing."
                </p>
                <div className="font-bold text-white">Naveed Butt</div>
                <div className="text-xs text-sky-400 uppercase tracking-widest">Founder & Lead Developer</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="bg-slate-900/30 py-32 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-4xl mx-auto">
            <div className="p-10 bg-slate-900/50 border border-white/10 rounded-xl">
              <h3 className="text-xl font-bold mb-4 text-sky-400">Our Mission</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                To empower businesses through digital excellence. We don't just code; 
                we solve problems and build ecosystems for growth.
              </p>
            </div>
            <div className="p-10 bg-slate-900/50 border border-white/10 rounded-xl">
              <h3 className="text-xl font-bold mb-4 text-sky-400">Core Expertise</h3>
              <div className="flex flex-wrap gap-2">
                {['React', 'Node.js', 'UI/UX Design', 'Shopify'].map((skill, i) => (
                  <span key={i} className="bg-white/5 border border-white/10 px-3 py-1 rounded-full text-[12px] text-slate-300">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
